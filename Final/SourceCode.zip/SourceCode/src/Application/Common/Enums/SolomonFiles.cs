﻿namespace OptiRoute.Application.Common.Enums
{
    public enum SolomonFiles
    {
        Instance,
        Best
    }
}