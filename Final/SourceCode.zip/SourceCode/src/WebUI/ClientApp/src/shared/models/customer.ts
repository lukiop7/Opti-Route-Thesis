export interface Customer {
  date: Date;
  lat: number;
  lng: number;
}
