﻿namespace OptiRoute.Infrastructure.Files.FileReaders.BenchmarkTemplates
{
    public class BenchmarkBestTemplate
    {
        public BenchmarkBestTemplate()
        {
            MinimumNumberOfLines = 6;
        }
        public int MinimumNumberOfLines = 6;
    }
}